package DB.DBproject;

/** * @author Wael Abouelsaadat */ 

public class DBAppException extends Exception {

	public DBAppException() {
		super();
	}
	public DBAppException( String strMessage ){
		super( strMessage );
	}
	

}