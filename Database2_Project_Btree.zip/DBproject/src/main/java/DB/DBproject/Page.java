package DB.DBproject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


public class Page implements  java.io.Serializable  {
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	private Vector<Hashtable<String,Object>> tuples;
	private String pageName;
	public static int page;
	
	
	
	public Page() {
		tuples=new Vector<Hashtable<String, Object>>(); //specifies tuples per page
		page++; 
		this.pageName="Page"+(page); 
	}
	
	public Page(String s) {
		this.pageName=s;
		tuples=new Vector<Hashtable<String, Object>>(); //specifies tuples per page
	}
	
	public Page(int i) {
		return;
	}
	
	public String getPageName() {
		return pageName;
	}
	
	
	
	@Override
	public String toString() { 
		//override toString
		String s=this.pageName+ " ";
		for(int i=0;i<tuples.size(); i++) {
			
			Hashtable H=tuples.get(i);
			Enumeration<String> keys = H.keys();
			   
			while(keys.hasMoreElements()) {
			    	String name=keys.nextElement();
			    	Object value=H.get(name);
			s=s+ name + ":" + value + " , ";   }
			s=s+"\n";
			
			
			 
		}
		return s;
	}
	
	public String PagetoString() { 
		String s=this.pageName+ " ";

			s=s+this.toString();   
			s=s+"\n";
		return s; 
		
	}

	
	public void serializePage(Page p){
		
		FileOutputStream file;
		try {
			file = new FileOutputStream( System.getProperty("user.dir") +  File.separator + p.getPageName() + ".ser");
		
        ObjectOutputStream out = new ObjectOutputStream(file);
        out.writeObject(p);
        out.close();
        file.close();
       }
		
		catch(IOException e) {
			e.printStackTrace();}

	}
	
	public static Page deserializePage(String name) {
		Page p=null;
		try {
			FileInputStream file = new FileInputStream( System.getProperty("user.dir") +  File.separator + name + ".ser");
	        ObjectInputStream in = new ObjectInputStream(file);
	        p = (Page) in.readObject(); 
	        in.close();
	        file.close();
	        return p;
		}
		catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return p;
	
	}
	
	public Vector<Hashtable<String,Object>> getPageTuples(){
		return this.tuples;
	}
	
	public void setPageTuples(Vector<Hashtable<String,Object>> tuples) {
		this.tuples=tuples;
	}
	
	public void setPageNumbers(int n) {
		page=n;
	}
	

}
	

