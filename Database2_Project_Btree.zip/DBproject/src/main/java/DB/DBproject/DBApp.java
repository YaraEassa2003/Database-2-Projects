package DB.DBproject;

/** * @author Wael Abouelsaadat */ 

import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import java.nio.*;
import java.sql.*;



public class DBApp extends DBAppException {
	
	FileWriter writer;
	public static Vector<Hashtable<String,BTree>> trees=new Vector<Hashtable<String,BTree>>(); 
	public static Vector<Table> tables=new Vector<Table>();
	public Hashtable<String,String> clustering=new Hashtable<String,String>();
	public static Vector<Page> pageVector=new Vector<Page>();
	public static Vector<Hashtable<String,String>> indices=new Vector<Hashtable<String,String>>();
	public static int max; 

	public DBApp( ) throws IOException{
		init();
		maxValue();
		
	}

	// this does whatever initialization you would like 
	// or leave it empty if there is no code you want to 
	// execute at application startup 
	public void init( ) throws IOException {
		FileWriter writer= new FileWriter((new File("metadata.csv")), true);
		writer.close();
		
	}
	
	

	public int getMax() {
		return max;
	}
	

	// following method creates one table only
	// strClusteringKeyColumn is the name of the column that will be the primary
	// key and the clustering column as well. The data type of that column will
	// be passed in htblColNameType
	// htblColNameValue will have the column name as key and the data 
	// type as value
	public void createTable(String strTableName, 
							String strClusteringKeyColumn,  
							Hashtable<String,String> htblColNameType) throws DBAppException, IOException{ 
		BufferedReader br = new BufferedReader(new FileReader("metadata.csv")); //close br 
		String line = br.readLine();
		while (line != null) {
			String[] sp = line.split(",");
			if (sp[0].equals(strTableName)) {
				throw new DBAppException("Table already exists");
			} 
			
		line=br.readLine();
		}
		
		
		Table temp=new Table(strTableName);
		tables.add(temp);
		temp.serializeTable(temp);
		StringBuilder meta = new StringBuilder();
		
	    Enumeration<String> keys = htblColNameType.keys();
	    while(keys.hasMoreElements()) {
	    	
	    	String name=keys.nextElement();
	    	String type=htblColNameType.get(name);
	    	
	    	
	    	if(type.equals(null) || name.equals(null) || (!type.equals("java.lang.Integer") && !type.equals("java.lang.String") 
	    			&& !type.equals("java.lang.double"))) {
	    		
				throw new DBAppException("Invalid entry");
			}
	    	
	    	String key="false";
			if (strClusteringKeyColumn.equals(name)) {
				key= "true";
			}
			
	    	String input= strTableName + ","+ name +","+ type+","+ key+","+ null+","+ null;
	    	meta.append(input).append("\n");
	   }
		
	    
	    BufferedWriter writer2 = new BufferedWriter(new FileWriter("metadata.csv"));
        writer2.write(meta.toString());
        writer2.newLine();
        writer2.close(); 
	    br.close();			
		//throw new DBAppException("not implemented yet");
		
	}
	
	//gets N
	public int maxValue() throws IOException {
		Properties p = new Properties();
	    String filename = "resources/DBApp.config";
	    
	    try (FileInputStream file = new FileInputStream(filename)) {
	        p.load(file);
	        String maxRowsCount = p.getProperty("MaximumRowsCountinPage");
	        if (maxRowsCount == null) {
	            throw new IOException("MaximumRowsCountinPage not found in DBApp.config");
	        }
	        max = Integer.parseInt(maxRowsCount);
	        
	        return max;
	        
	    } catch (FileNotFoundException e) {
	        System.err.println("DBApp.config file not found");
	        throw e;
	    } catch (IOException e) {
	        System.err.println("Error reading DBApp.config");
	        throw e;
	    }
		
		
			
		}	


	// following method creates a B+tree index 
	public void createIndex(String   strTableName,
							String   strColName,
							String   strIndexName) throws DBAppException, IOException{ //done bas revise el B+tree / mhtagen n check table exists and index doesnt exist
		BufferedReader br = new BufferedReader(new FileReader("metadata.csv"));  
		String l = br.readLine();
		while (l != null) {
			String[] sp = l.split(",");
			if (sp[0].equals(strTableName) && sp[1].equals(strColName)&& sp[4]!=null&& sp[5].equalsIgnoreCase("B+tree") ) {
				throw new DBAppException("index already exists on this column in this table");
			} 
			l=br.readLine();
		}
		
		BTree temp=new BTree(strIndexName);
		
		Hashtable<String, BTree> tempHash=new Hashtable<>();
	
		tempHash.put(strIndexName,temp);
		trees.add(tempHash);
		
		String FilePath = "metadata.csv";

        try {
            BufferedReader rdr = new BufferedReader(new FileReader(FilePath));
            String line;
            StringBuilder meta = new StringBuilder();
            while ((line = rdr.readLine()) != null) {
                if(line.length()!=0) {
            	String[] parts = line.split(",");
            	if(parts.length!=1){
                if(parts[1].equals(strColName) && parts[0].equals(strTableName) ) {
                	
                parts[4] = strIndexName;
                
                parts[5]="B+tree";
               
                
               
                }  
                meta.append(String.join(",", parts)).append("\n"); 
                BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
                writer.write(meta.toString());
                writer.newLine();
                writer.close();} } }
                rdr.close();
               
            }
      
            
          catch (IOException e) {
            e.printStackTrace();}
        
        Table tableTemp=null;
        tableTemp=Table.deserializeTable(strTableName);

        if(tableTemp.tupleVector!=null) {
	      if(tableTemp!=null) {  
	    	  Vector<Tuple> V=tableTemp.tupleVector;
	        	for (int i = 0; i < V.size(); i++) { 
	        		Tuple t=(Tuple) V.get(i); 
	        		Hashtable<String, Object> H=((Tuple)V.get(i)).getHTBL();
	        		Object O=H.get(strColName);
	        		Vector <Tuple> insertVector=new Vector<Tuple>();
	        		insertVector.add(t);
	        		
	        		if (O instanceof String) {
	        			String x=(String)O;
	        			Vector<Tuple> tempV=null;
	        			if(temp.search(x)!=null) {
	        				tempV=(Vector<Tuple>) temp.search(x);
	        				tempV.add((Tuple)t);
	        				temp.delete((String)O);
	        				temp.insert((String)O, (Vector<Tuple>)tempV); //hena ymkn fe tare2a more efficient than delete w insert
	        				}
	        			
	        			else {
	        				temp.insert((String)O, insertVector);
	        			}
	        		}
	        		
	        		else if (O instanceof Integer) {
	        			int x=(Integer)O;
	        			Vector<Tuple> tempV=null;
	        			if(temp.search(x)!=null) {
	        				tempV=(Vector<Tuple>) temp.search(x);
	        				tempV.add((Tuple)t);
	        				temp.delete((Integer)O);
	        				temp.insert((Integer)O, (Vector<Tuple>)tempV);
	        				}
	        			
	        			else {
	        				temp.insert((Integer)O, insertVector);
	        			}
	        		}
	        			
	        		else if (O instanceof Double) {
	        			Double x=(Double)O;
	        			Vector<Tuple> tempV=null;
	        			if(temp.search(x)!=null) {
	        				tempV=(Vector<Tuple>) temp.search(x);
	        				tempV.add((Tuple)t);
	        				temp.delete((Double)O);
	        				temp.insert((Double)O, (Vector<Tuple>)tempV);
	        				}
	        			
	        			else {
	        				temp.insert((Double)O, insertVector);
	        			}
	        		}
	        	
	        		
	        		else {
	        			throw new DBAppException("Type is not supported");
	        		}
	        		
	        	}
	        	
	        }
		
	}
        
	      
	      Hashtable<String,String>tempV= tableTemp.getIndices();
	      tempV.put(strColName, strIndexName);
	      tableTemp.setIndices(tempV);
	      tableTemp.serializeTable(tableTemp);
	      temp.serializeTree(temp);
	      
   
}
	
	public void insertIndexHelper(String strTableName, Object O, String index, Tuple tuple) throws DBAppException, FileNotFoundException, IOException {
		BTree temp=BTree.deserializeTree(index);
		
		Vector <Tuple> insertVector=new Vector<Tuple>();
    	insertVector.add(tuple);
    		if (O instanceof String) {
    			String x=(String)O;
    			Vector<Tuple> tempV=null;
    			if(temp.search(x)!=null) {
    				tempV=(Vector<Tuple>) temp.search(x);
    				tempV.add((Tuple)tuple);
    				temp.delete((String)O);
    				temp.insert((String)O, (Vector<Tuple>)tempV);
    				}
    			
    			else {
    				temp.insert((String)O, insertVector);
    			}
    		}
    	
    		
    		else if (O instanceof Integer) {
        			int x=(int)O;
        			Vector<Tuple> tempV=null;
        			if(temp.search(x)!=null) {
        				tempV=(Vector<Tuple>) temp.search(x);
        				tempV.add((Tuple)tuple);
        				temp.delete((int)O);
        				temp.insert((int)O, (Vector<Tuple>)tempV);
        				}
        			
        			else {
        				temp.insert((int)O, insertVector);
        			}
        		}
    			
    		else if (O instanceof Double) {
        			double x=(double)O;
        			Vector<Tuple> tempV=null;
        			if(temp.search(x)!=null) {
        				tempV=(Vector<Tuple>) temp.search(x);
        				tempV.add((Tuple)tuple);
        				temp.delete((double)O);
        				temp.insert((double)O, (Vector<Tuple>)tempV);
        				}
        			
        			else {
        				temp.insert((double)O, insertVector);
        			}
        		} 
    		
    		else {
    			throw new DBAppException("Type is not supported");
    		}
    		
    		temp.serializeTree(temp);
    	}
	
		
	public static String ClusteringKeyRdr(String strTableName) throws DBAppException, IOException { //
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
        String s=null;

        
	    	while ((line = rdr.readLine()) != null) {
	        	String[] parts = line.split(",");
	            if(parts[0].equals(strTableName) && parts[3].equalsIgnoreCase("true")) {
	            	s= parts[1];
	            	
	            	
	            }
	    	}
	    	
	    	return s;
	            	
	    }
	            	

	// following method inserts one row only. 
	// htblColNameValue must include a value for the primary key
	public void insertIntoTable(String strTableName, 
								Hashtable<String,Object>  htblColNameValue) throws DBAppException, IOException{
		
		Tuple t = new Tuple(strTableName, htblColNameValue);
		
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
        
        Enumeration<String> keys = htblColNameValue.keys();
	    ArrayList <String> values=new ArrayList<String>();
	    while(keys.hasMoreElements()) {
	    	
	    	String name=keys.nextElement();
	    	Object value=htblColNameValue.get(name);
	    	
        
	    	while ((line = rdr.readLine()) != null) {
            
        	
        	
        	String[] parts = line.split(",");
            
            if(parts[1].equals(name) && parts[0].equals(strTableName) && parts[5]!=null && (parts[5].equals("B+tree")) ) {
            	String indexName=parts[4];
            	insertIndexHelper(name, value,indexName, t);
            	} 
            break;
            	
           }
	    }
		
		boolean flag=false;
		Table table=null;
		table=Table.deserializeTable(strTableName);
		table.addTuple(t, strTableName);
		if(table!=null) {
			flag=true;
		}
		table.serializeTable(table);
		
		if(flag==false) {
			throw new DBAppException("Table does not exist");}

	}


	// following method updates one row only
	// htblColNameValue holds the key and new value 
	// htblColNameValue will not include clustering key as column name
	// strClusteringKeyValue is the value to look for to find the row to update.
	public void updateTable(String strTableName, 
							String strClusteringKeyValue,
							Hashtable<String,Object> htblColNameValue)  throws DBAppException, IOException {
		if(TableReader(strTableName)==false) {
			throw new DBAppException("Table does not exist");}
		Table t=Table.deserializeTable(strTableName);
		if (t.isEmpty()){
			throw new DBAppException("Table is empty");}
		
		BTree changeTree=null;
		BTree OldTree=null;
		String indexName=null;
		String clusteringKey=ClusteringKeyRdr(strTableName);
		Hashtable<String,String> temph=t.getIndices();
		String clusIndexName=temph.get(clusteringKey);
		
		if (clusIndexName != null) {
			
		changeTree = BTree.deserializeTree(clusIndexName);
		}
		
		Object clusteringKeyValue=null;
		Tuple changeTup=null;
		
		if(changeTree!=null) {
		if(changeTree.getSmallest().getKey(0) instanceof Integer) {
			clusteringKeyValue=Integer.parseInt(strClusteringKeyValue);
			Vector<Tuple> tempV=(Vector<Tuple>)changeTree.search((int)clusteringKeyValue);
			changeTup=tempV.get(0);
		}
		else {
			if(changeTree.getSmallest().getKey(0) instanceof Double) {
				clusteringKeyValue=Double.parseDouble(strClusteringKeyValue);
				Vector<Tuple> tempV=(Vector<Tuple>)changeTree.search((double)clusteringKeyValue);
				changeTup=tempV.get(0);
			}
			
			else {
				clusteringKeyValue=strClusteringKeyValue;
				Vector<Tuple> tempV=(Vector<Tuple>)changeTree.search((String)clusteringKeyValue);
				changeTup=tempV.get(0);
		}
		
	}
		}
		
		else {
			int position=binarySearchIterator(t.tupleVector, strClusteringKeyValue, clusteringKey);
			if(position!=-1) {
				changeTup=t.tupleVector.get(position);
			}	
		}
		
		if(changeTup!=null) {
		
		Enumeration<String> changeCol = htblColNameValue.keys();
		Hashtable<String, Object> updateHash=changeTup.getHTBL();
		Hashtable<String,String> index=t.getIndices();
		Enumeration<String> indexEnum=index.keys();
		
		while(changeCol.hasMoreElements()){
		    	String key=changeCol.nextElement();
		    	Object value=htblColNameValue.get(key);
		    	
		    	if(!updateHash.containsKey(key)) {
		    		throw new DBAppException("Some columns do not exist in this table");
		    	}
		    	
		    	while(indexEnum.hasMoreElements()) {
					if (key.equals(indexEnum.nextElement())) {
						      
								indexName=index.get(key);
								
								if (indexName!=null) {
									
								changeTree=BTree.deserializeTree(indexName);
								OldTree=BTree.deserializeTree(indexName);
								
								}
								
						
					if(changeTree!=null) {
					
					Hashtable<String, BTree> oldHTB=new Hashtable<String,BTree>();
					oldHTB.put(indexName, OldTree);
					Hashtable<String, BTree> newHTB=new Hashtable<String,BTree>();
					
					changeTree.delete(key);
					changeTree.insert(key, changeTup);
					newHTB.put(indexName, changeTree);
					DBApp.trees.remove(oldHTB);
					DBApp.trees.add(newHTB);
					}
				}
						
					
					
				}
		    	
		    	updateHash.put(key, value);	
		}
			int i=t.tupleVector.indexOf(changeTup);
			changeTup.setHTBL(updateHash);
			t.tupleVector.set(i,changeTup);
		}
			
			t.serializeTable(t);
		
	}


	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search 
	// to identify which rows/tuples to delete. 	
	// htblColNameValue enteries are ANDED together
	public void deleteFromTable(String strTableName, 
								Hashtable<String,Object> htblColNameValue) throws DBAppException, IOException {
			
		Table t=Table.deserializeTable(strTableName);
			if(t==null) {
				throw new DBAppException("Table does not exist");}
			if(t.isEmpty()){
				throw new DBAppException("Table is empty");}
			
			
			Enumeration<String> deleteCol = htblColNameValue.keys();
			Object Deletes [][] = new Object [htblColNameValue.size()][2];
			int count=0;
			
			
			
			while(deleteCol.hasMoreElements()){
		    	String key=deleteCol.nextElement();
		    	Object value=htblColNameValue.get(key); 
		    	
		    	if(count<Deletes.length) {
		    		Deletes[count][0]= key;
		    		Deletes[count][1]= value;
		    	}
		    	count++;
			}
			
			t.deleteHelper(Deletes, htblColNameValue);
			
			t.serializeTable(t);
			}
	


	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, 
									String[]  strarrOperators) throws DBAppException, IOException {
		if(arrSQLTerms.length!=strarrOperators.length+1) {
			throw new DBAppException("Invalid query");
		}
		
		for(int i=0; i<strarrOperators.length;i++) {
			if(COperatorTypeReader(strarrOperators[i])==false) {
				throw new DBAppException("Invalid query");
			}
		}
		
		
		
		Vector<Tuple> resultVector=new Vector<Tuple>();
		int count=-1;
		for(int i=0; i<arrSQLTerms.length;i++) {
			String tableName=arrSQLTerms[i]._strTableName; 
			if (TableReader(tableName)==false) {
				throw new DBAppException("Table does not exist");
			}
			
			Table t=Table.deserializeTable(tableName);
				
			if(t.tupleVector.isEmpty()) {
					throw new DBAppException("Table is Empty");
				}
				
			
			
			Hashtable<String,String>indices= t.getIndices();
			BTree tree=null;
			Vector<Tuple> VectorTup=new Vector<Tuple>();
			Vector<Tuple> tempVector=new Vector<Tuple>();
			
			String ColumnName=arrSQLTerms[i]._strColumnName;
			if (ColumnReader(tableName,ColumnName)==false) {
				throw new DBAppException("Column does not exist in this table");
			}
			
			if(indices.containsKey(ColumnName)) {
				String index=indices.get(ColumnName);
				tree=BTree.deserializeTree(index);
			}
			
			
			
			String Operator=arrSQLTerms[i]._strOperator;
			if(OperatorTypeReader(Operator)==false) {
				throw new DBAppException("Invalid operator");
			} 
			
			
			Object Value=arrSQLTerms[i]._objValue; 
			
			String ColumnType=ColumnTypeReader(tableName, ColumnName);
			if(ColumnType.equalsIgnoreCase("java.lang.Integer")) {
				if(!(arrSQLTerms[i]._objValue instanceof Integer)) {
					throw new DBAppException("Data type of value does not match column data type");
				}
				
				if(tree!=null) {
					VectorTup=(Vector<Tuple>) tree.search((int)Value);
					if (Operator.equals("!=")) {
						BTreeLeafNode node=tree.getSmallest();
						while (node.getRightSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 if(!VectorTup.equals((Vector<Tuple>) tree.search((int)Value))) {
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));}
						 }
					}
				} 
			}
					
					else {
					
					if (Operator.equals("=") || Operator.contains("=")) {
						for(int l=0;l<VectorTup.size();l++){
							tempVector.add(VectorTup.get(l));
					} 
				}
						
					if (Operator.equals(">") || Operator.contains(">")) {
						BTreeLeafNode node=tree.LeafNodeFinder((int)Value);
						while (node.getRightSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));
						 }
				}
						 node=(BTreeLeafNode) node.getRightSibling();
			}
		}
					else if (Operator.equals("<") || Operator.contains("<")) {
						BTreeLeafNode node=tree.LeafNodeFinder((int)Value);
						while (node.getLeftSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));
						 }
				}
						 node=(BTreeLeafNode) node.getLeftSibling();
			}
		}
					
				} 
			}
				else {
					for (int j=0;j<t.tupleVector.size();j++) {
						Tuple tuple=t.tupleVector.get(j);
						Hashtable<String,Object> tupleHTBL=tuple.getHTBL();
						int tempValue= (int) tupleHTBL.get(ColumnName);
						if(Operator.equals("!=")) {
							if(tempValue!=(int)Value) {
								tempVector.add(tuple);
							}
						}
						else {
						if(Operator.equals("=") || Operator.contains("=")) {
							if(tempValue==(int)Value) {
								tempVector.add(tuple);
						}
					}
						
						if(Operator.equals(">") || Operator.contains(">")) {
							if(tempValue>(int)Value) {
								tempVector.add(tuple);
						}
					}
						
						else if(Operator.equals("<") || Operator.contains("<")) {
							if(tempValue<(int)Value) {
								tempVector.add(tuple);
						}
					}
					
					  
					  
					
				}
			}
		}
		}
			
			
			if(ColumnType.equalsIgnoreCase("java.lang.String")) {
				if(!(arrSQLTerms[i]._objValue instanceof String)) {
					throw new DBAppException("Data type of value does not match column data type");
				}
				
				if(tree!=null) {
					VectorTup=(Vector<Tuple>) tree.search((String)Value);
					if (Operator.equals("!=")) {
						BTreeLeafNode node=tree.getSmallest();
						while (node.getRightSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 if(!VectorTup.equals((Vector<Tuple>) tree.search((String)Value))) {
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));}
						 }
						}
					} 
						}
					
					else {
					
					if (Operator.equals("=") || Operator.contains("=")) {
						for(int l=0;l<VectorTup.size();l++){
							tempVector.add(VectorTup.get(l));
					} 
						}
					else {
						throw new DBAppException("Invalid operator for string");
					}
					
				} 
			}
				
				else {
					for (int j=0;j<t.tupleVector.size();j++) {
						Tuple tuple=t.tupleVector.get(j);
						Hashtable<String,Object> tupleHTBL=tuple.getHTBL();
						String tempValue= (String) tupleHTBL.get(ColumnName);
						
						if(Operator.equals("!=")) {
							if(!tempValue.equals((String)Value)) {
								tempVector.add(tuple);
							}
						}
						else {
						if(Operator.equals("=")) {
							if(tempValue.equalsIgnoreCase((String)Value)) {
								tempVector.add(tuple);
						}
					}
						
						if(Operator.equals(">") || Operator.equals("<=") || Operator.equals("<") || Operator.equals(">=")) {
							throw new DBAppException("Operator is not supported for type string");
						}
					}
				}
			}
		}
				
		
			
			if(ColumnType.equalsIgnoreCase("java.lang.Double")) {
				if(!(arrSQLTerms[i]._objValue instanceof Double)) {
					throw new DBAppException("Data type of value does not match column data type");
				}
				
				if(tree!=null) {
					VectorTup=(Vector<Tuple>) tree.search((double)Value);
					if (Operator.equals("!=")) {
						BTreeLeafNode node=tree.getSmallest();
						while (node.getRightSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 if(!VectorTup.equals((Vector<Tuple>) tree.search((double)Value))) {
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));}
						 }
						}
					} 
				}
					
					else {
					
					if (Operator.equals("=") || Operator.contains("=")) {
						for(int l=0;l<VectorTup.size();l++){
							tempVector.add(VectorTup.get(l));
					} }
						
					if (Operator.equals(">") || Operator.contains(">")) {
						BTreeLeafNode node=tree.LeafNodeFinder((double)Value);
						while (node.getRightSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));
						 }
				}
						 node=(BTreeLeafNode) node.getRightSibling();
			}
		}
					else if (Operator.equals("<") || Operator.contains("<")) {
						BTreeLeafNode node=tree.LeafNodeFinder((double)Value);
						while (node.getLeftSibling()!=null) {
						 int keycount=node.getKeyCount();
						 for (int g=0;g<keycount;g++) {
							 VectorTup=(Vector<Tuple>) node.getValue(g);
							 for(int l=0;l<VectorTup.size();l++){
									tempVector.add(VectorTup.get(l));
						 }
				}
						 node=(BTreeLeafNode) node.getLeftSibling();
			}
		}
					
				} 
			}
				
				else {
					for (int j=0;j<t.tupleVector.size();j++) {
						Tuple tuple=t.tupleVector.get(j);
						Hashtable<String,Object> tupleHTBL=tuple.getHTBL();
						double tempValue= (double) tupleHTBL.get(ColumnName);
						if(Operator.equals("!=")) {
							if(tempValue!=(double)Value) {
								tempVector.add(tuple);
							}
						}
						else {
						
						if(Operator.equals("=") || Operator.contains("=")) {
							if(tempValue==(double)Value) {
								tempVector.add(tuple);
						}
					}
						
						if(Operator.equals(">") || Operator.contains(">")) {
							if(tempValue>(double)Value) {
								tempVector.add(tuple);
						}
					}
						
						if(Operator.equals("<") || Operator.contains("<")) {
							if(tempValue<(double)Value) {
								tempVector.add(tuple);
						}
					}
						}
					}
				}
				
			}
			if(count==-1) {
				resultVector=tempVector;
			}
			
			else if(count<strarrOperators.length) {
				if(strarrOperators[count].equalsIgnoreCase("OR") || strarrOperators[count].equalsIgnoreCase("XOR")){
					for(int k=0;k<tempVector.size();k++) {
						resultVector.add(tempVector.get(k)); }
				
					if(strarrOperators[count].equalsIgnoreCase("XOR")) {
						Vector<Tuple> temp=andHelper(resultVector, tempVector);
						for(int l=0;l<temp.size();l++) {
							if(resultVector.contains(temp.get(l))) {
								resultVector.remove(temp.get(l));}
					}
				}
					
			}
				
				else if (strarrOperators[count].equalsIgnoreCase("AND")) {
					resultVector=andHelper(resultVector, tempVector);
				}
				
			}
			count++;
				

	}
		Vector <String> result= new Vector<String>();
		
		for(int i=0;i<resultVector.size();i++) {
			String s="";
			Tuple t=resultVector.get(i);
			Hashtable H=t.getHTBL();
			Enumeration<String> keys = H.keys();
		    while(keys.hasMoreElements()) {
		    	String columnName=keys.nextElement();
		    	Object data=H.get(columnName);
		    	s=s+" " +data;
		}
		    result.add(s); }
		
		Collection<String> uniqueVector=new Vector<String>();
		uniqueVector = result.stream().distinct().collect(Collectors.toCollection(Vector::new));
		
		return uniqueVector.iterator();

}
	
	public Vector<Tuple> andHelper(Vector<Tuple> firstVec, Vector<Tuple> secondVec) throws DBAppException, IOException{
		Vector<Tuple> resultVec=new Vector<Tuple>();
		for(int i=0;i<firstVec.size();i++) {
			Tuple t=firstVec.get(i);
			Hashtable<String,Object> H1=t.getHTBL();
			
			String s1= ClusteringKeyRdr(t.strTableName);
			Object clusteringTemp=H1.get(s1);
			
		for (int j=0;j<secondVec.size();j++) {
			Tuple t2=secondVec.get(j);

			Hashtable<String,Object> H2=t2.getHTBL();
			Object clusteringTemp2=H2.get(s1);

			if (clusteringTemp2.equals(clusteringTemp)) {
				resultVec.add(t);
			}
		}
	}
				return resultVec;
				
}
	
	
	public static int binarySearchIterator(Vector<Tuple> tupleVector, Object value, String clusteringKeyValue) throws DBAppException {
		
		if(value instanceof Integer) {
		
		  int low = 0;
		  int high = tupleVector.size() - 1;

		  while (low <= high) {
		    int mid = (low + high) / 2;
		   
		    Tuple t= tupleVector.get(mid);
		    Hashtable<String,Object> H=t.getHTBL();
		    int insertedValue=(int) H.get(clusteringKeyValue);
		    
		    if (insertedValue == (int)value) {
		      return mid;
		    } else if (insertedValue < (int)value) {
		      low = mid + 1;
		    } else {
		      high = mid - 1;
		    }
		  }
		}
		
		else if(value instanceof String) {
			
			  int low = 0;
			  int high = tupleVector.size() - 1;

			  while (low <= high) {
			    int mid = (low + high) / 2;
			   
			    Tuple t= tupleVector.get(mid);
			    Hashtable<String,Object> H=t.getHTBL();
			    String insertedValue=(String) H.get(clusteringKeyValue);
			    
			    if (insertedValue.equals((String)value)) {
			      return mid;
			    } else if (insertedValue.compareTo((String)value)==-1) {
			      low = mid + 1;
			    } else {
			      high = mid - 1;
			    }
			  }
			}
		else if(value instanceof Double) {
			
			  int low = 0;
			  int high = tupleVector.size() - 1;

			  while (low <= high) {
			    int mid = (low + high) / 2;
			   
			    Tuple t= tupleVector.get(mid);
			    Hashtable<String,Object> H=t.getHTBL();
			    Double insertedValue=(Double) H.get(clusteringKeyValue);
			    
			    if (insertedValue.equals((Double)value)) {
			      return mid;
			    } else if (insertedValue<(Double)value) {
			      low = mid + 1;
			    } else {
			      high = mid - 1;
			    }
			  }
			}
		else {
			throw new DBAppException("Data type of clustering key is not valid for this table");
		}
		

		  return -1;
		}

	public boolean OperatorTypeReader(String op) {
		
		switch(op) {
		
		case "=":return true;
		case ">":return true;
		case "<":return true;
		case ">=":return true;
		case "<=":return true;
		case "!=":return true;
		default:return false;
		
		}
		
	}
	public boolean COperatorTypeReader(String cop) {
		switch(cop) {
		case "AND":return true;
		case "OR":return true;
		case "XOR":return true;
		default : return false;
		}
	}
	
	
	public String ColumnTypeReader(String tableName, String ColumnName) throws IOException {
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
        String s=null;
        
	    	while ((line = rdr.readLine()) != null) {

	        	String[] parts = line.split(",");
	            if(parts[1].equals(ColumnName) && parts[0].equals(tableName)) {
	            	s= parts[2];
	            	break;
	            }
	    	}
	    	return s;
		
	}
	
	public boolean TableReader(String TableName) throws IOException {
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
        boolean s=false;
        
	    	while ((line = rdr.readLine()) != null) {

	        	String[] parts = line.split(",");
	            if(parts[0].equals(TableName)) {
	            	s= true;
	            	break;
	            }
	    	}
	    	return s;
		
	}
	
	public boolean ColumnReader(String TableName, String ColumnName) throws IOException {
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
        boolean s=false;
        
	    	while ((line = rdr.readLine()) != null) {

	        	String[] parts = line.split(",");
	            if(parts[0].equals(TableName) && parts[1].equals(ColumnName)) {
	            	s= true;
	            }
	    	}
	    	return s;
		
	}
	
	
	
	public void indexReader() throws IOException {
		BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
        String line;
        StringBuilder meta = new StringBuilder();
      
    	while ((line = rdr.readLine()) != null) {
        
    	
    	
    	String[] parts = line.split(",");
        
    	
        if(parts[4]!=null ) {
        	Hashtable<String,String> H=new Hashtable<String,String>();
        	H.put(parts[0], parts[4]);
        	indices.add(H);
        
        	
        	} 
        	
       }
    }
	
	public static int binarySearchIteratorPage(Vector<Page> PageVector, String value) {
		
		
		  int low = 0;
		  int high = PageVector.size() - 1;

		  while (low <= high) {
		    int mid = (low + high) / 2;
		   
		    Page t= PageVector.get(mid);
		    String insertedValue=t.getPageName();
		    
		    if (insertedValue.equals(value)) {
		      return mid;
		    } else if (insertedValue.compareTo((String)value)==-1) {
		      low = mid + 1;
		    } else {
		      high = mid - 1;
		    }
		  }
		


	  return -1;
	}
			
	
	public static Vector<Page> getPageVector(){
		return pageVector;
	}
	
	public static void setPageVector(Vector<Page> page){
		 pageVector=page;
	}

			
	public static void main( String[] args ){
		
		try{
				String strTableName = "Student";
				DBApp	dbApp = new DBApp( );
				
				Hashtable htblColNameType = new Hashtable( );
				htblColNameType.put("id", "java.lang.Integer");
				htblColNameType.put("name", "java.lang.String");
				htblColNameType.put("gpa", "java.lang.double");
//				dbApp.createTable( strTableName, "id", htblColNameType );
//				dbApp.createIndex( strTableName, "gpa", "gpaIndex" );

				Hashtable htblColNameValue = new Hashtable( );
				htblColNameValue.put("id", new Integer( 2343432 ));
				htblColNameValue.put("name", new String("Ahmed Noor" ) );
				htblColNameValue.put("gpa", new Double( 0.95 ) );
				//dbApp.insertIntoTable( strTableName , htblColNameValue );

				htblColNameValue.clear( );
				htblColNameValue.put("id", new Integer( 453455 ));
				htblColNameValue.put("name", new String("Ahmed Noor" ) );
				htblColNameValue.put("gpa", new Double( 0.95 ) );
				//dbApp.insertIntoTable( strTableName , htblColNameValue );

				htblColNameValue.clear( );
				htblColNameValue.put("id", new Integer( 5674567 ));
				htblColNameValue.put("name", new String("Dalia Noor" ) );
				htblColNameValue.put("gpa", new Double( 1.25 ) );
				//dbApp.insertIntoTable( strTableName , htblColNameValue );

				htblColNameValue.clear( );
				htblColNameValue.put("id", new Integer( 23498 ));
				htblColNameValue.put("name", new String("John Noor" ) );
				htblColNameValue.put("gpa", new Double( 1.5 ) );
				//dbApp.insertIntoTable( strTableName , htblColNameValue );

				htblColNameValue.clear( );
				htblColNameValue.put("id", new Integer( 78452 ));
				htblColNameValue.put("name", new String("Zaky Noor" ) );
				htblColNameValue.put("gpa", new Double( 0.88 ) );
				//dbApp.insertIntoTable( strTableName , htblColNameValue );


				SQLTerm[] arrSQLTerms;
				arrSQLTerms = new SQLTerm[2];
				arrSQLTerms[0]=new SQLTerm();  
				arrSQLTerms[1]=new SQLTerm();
				arrSQLTerms[0]._strTableName =  "Student";
				arrSQLTerms[0]._strColumnName=  "name";
				arrSQLTerms[0]._strOperator  =  "=";
				arrSQLTerms[0]._objValue     =  "John Noor";

				arrSQLTerms[1]._strTableName =  "Student";
				arrSQLTerms[1]._strColumnName=  "gpa";
				arrSQLTerms[1]._strOperator  =  "=";
				arrSQLTerms[1]._objValue     =  new Double( 1.5 );

				String[]strarrOperators = new String[1];
				strarrOperators[0] = "OR";
				// select * from Student where name = "John Noor" or gpa = 1.5;
				Iterator resultSet = dbApp.selectFromTable(arrSQLTerms , strarrOperators);
				while(resultSet.hasNext()) {
				System.out.println(resultSet.next().toString());
			}
		}
			catch(Exception exp){
				exp.printStackTrace( );
			}
		}
}
	

