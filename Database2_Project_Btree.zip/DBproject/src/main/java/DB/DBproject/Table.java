package DB.DBproject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Iterator;


public class Table implements  java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String name;
	public Vector<Tuple> tupleVector;
	public Vector<Tuple> Vec;
	Hashtable<String,String> hash;
	
	public Table(String strTableName) {
		
		this.name=strTableName;
		hash=new Hashtable<String,String>(); 
		tupleVector=new Vector<Tuple>();
		
	}
	
	public Hashtable<String,String> getIndices(){
		return this.hash;
	}
	
	public void setIndices(Hashtable<String,String> hash) {
		this.hash=hash;
	}
	
	public static Table deserializeTable(String t){
		Table p = null;
		  String filePath = System.getProperty("user.dir") +  File.separator + t + ".ser";
		  try {
		    FileInputStream file = new FileInputStream(filePath);
		    ObjectInputStream in = new ObjectInputStream(file);
		    p = (Table) in.readObject(); 
		    in.close();
		    file.close();
		  } catch (IOException | ClassNotFoundException e) {
		    e.printStackTrace();
		  }

		  return p;
		}
	
	public void serializeTable(Table t)throws IOException {
		String name=this.name;
		  String filePath = System.getProperty("user.dir") + File.separator  + name + ".ser";
		  try (FileOutputStream file = new FileOutputStream(filePath);
		       ObjectOutputStream out = new ObjectOutputStream(file)) {
		    out.writeObject(t);
		  }
		}
	
	public boolean isEmpty() {
		if (tupleVector.isEmpty())
			return true;
		else
			return false;

		}
	
	
	public void addTuple(Tuple t, String tableName) throws DBAppException, IOException {
		
		if(tupleVector.size()==0) {
			tupleVector.add(t);
			addPage(t);
		}
		
		else {		
		Tuple tup=tupleVector.lastElement();
		Hashtable<String,Object> H=tup.getHTBL();
		String s= ClusteringKeyRdr(tableName);
		Hashtable<String, BTree> trees=this.getTree();
		BTree tree=trees.get(s);
		Object temp=H.get(s); 
		
		Hashtable<String,Object> H1=t.getHTBL();
		String s1= ClusteringKeyRdr(tableName);
		Object clusteringTemp=H1.get(s1);
		
		Hashtable<String,Object> ins=t.getHTBL();
		
		
		if(temp instanceof String) {
			if(tree!=null) {
				if(tree.search((String)clusteringTemp)!=null) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			else {
				if(DBApp.binarySearchIterator(tupleVector, clusteringTemp, s)!=-1) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			
			if(((String)temp).compareTo((String)ins.get(s))<0) { 
				tupleVector.add(t);
				addPage(t); 
		}
			else {
				splitPage(tableName ,t);

				
			}
	}
		
		else if (temp instanceof Integer) {
			if(tree!=null) {
				if(tree.search((int)clusteringTemp)!=null) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			else {
				if(DBApp.binarySearchIterator(tupleVector, clusteringTemp, s)!=-1) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			
			if((int)temp<(int)ins.get(s)||(int)temp==(int)ins.get(s)) {
				tupleVector.add(t);
				addPage(t);

			}
			
			else {
				splitPage(tableName ,t);
			}
		}
			
		else if (temp instanceof Double) {
			if(tree!=null) {
				if(tree.search((double)clusteringTemp)!=null) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			else {
				if(DBApp.binarySearchIterator(tupleVector, clusteringTemp, s)!=-1) {
					throw new DBAppException("Clustering key value already exists");
				}
			}
			if((double)temp<(double)ins.get(s)) {
				tupleVector.add(t);
				addPage(t);
			}
			
			else {
				splitPage(tableName ,t);
			}

		}
	}
}

	
	public void sortTuples() throws DBAppException, IOException { 
		Object[][] twoD=new Object[tupleVector.size()][2];
		int j=0;
		for (int i=0; i<tupleVector.size();i++) {
			
			Tuple t=tupleVector.get(i);
			Hashtable<String,Object> H=t.getHTBL();
			String s= ClusteringKeyRdr(this.name);
			Object temp=H.get(s); 
			
			if(j<twoD.length){
				twoD[j][0]=temp;
				twoD[j][1]=t;
				sortHelper(twoD);
				j++;
			}
			
		} 
		String st="";
        for(int k=0;k<twoD.length;k++) {
       	
       	 st=st+twoD[k][1]+ "\n";
        }
		
		tupleVector.removeAllElements();
		for(int m=0;m<twoD.length;m++) {
			tupleVector.add((Tuple) twoD[m][1]);
		}
		
	}
	
	public Object[][] sortHelper(Object[][] sort){
		int length=sort.length;
		   for (int i = 0; i < length - 1; i++) {
	             int min = i;
	             for (int j = i + 1; j < length; j++) {
	            	 if(sort[j][0] instanceof Integer)
	                 if ((int)sort[j][0] < (int)sort[min][0]) {
	                     min = j;
	                 }
	             }
	             if (min != i) {
	                 Object temp =sort[min][0];
	                 Object temp2=sort[min][1];
	                 sort[min][0] = sort[i][0];
	                 sort[min][1]=sort[i][1];
	                 sort[i][0] = temp;
	                 sort[i][1]=temp2;
	             }
	          
	         }
		   return sort;
	}


	
	public void addPage(Tuple t) throws FileNotFoundException, IOException, DBAppException { 
		if((tupleVector.size() / DBApp.max)>= DBApp.pageVector.size()){ 
			Page p=new Page();
			DBApp.pageVector.add(p); 
			Hashtable<String,Object> H=t.getHTBL();
			Vector<Hashtable<String,Object>> temp=p.getPageTuples();
			t.setPgName(p.getPageName());
			temp.add(H);
			p.setPageTuples(temp);
			p.serializePage(p);
			
		}
			
			else {
			Page p=DBApp.pageVector.lastElement();
			Page.deserializePage(p.getPageName());
			Hashtable<String,Object> H=t.getHTBL();
			Vector<Hashtable<String,Object>> temp=p.getPageTuples();
			temp.add(H);
			t.setPgName(p.getPageName());
			p.setPageTuples(temp);
			p.serializePage(p);
			sortTuples();
			}
		}
			
			
		
	
	
	
	public void splitPage(String tableName, Tuple t) throws DBAppException, IOException {
		boolean fTree=false;
		BTree searchTree=null;
		String clusteringKeyString=ClusteringKeyRdr(tableName);
		Hashtable H1=this.getTree();
		if(H1!=null) {
		searchTree=(BTree) H1.get(clusteringKeyString);}
		
		if(searchTree==null && fTree==false) { 
		Hashtable<String, Object> H=t.getHTBL();
		String s=ClusteringKeyRdr(tableName);
		Object x=H.get(s);
		boolean flag=false;

		for (int i=0; i<tupleVector.size();i++) { 
			Tuple leftTempTup=null;
			
			if(i!=0) {
				int j=i;
				leftTempTup=tupleVector.get(j--);
			}
			
			Tuple tempTup=tupleVector.get(i);
			Hashtable<String, Object> TempH=tempTup.getHTBL();
			Object y=TempH.get(s);
			boolean added=false;
			String pageName=tempTup.getPgName();
			
			if(x instanceof String) {
				if(((String) x).compareTo((String)y)==-1) {
					if(leftTempTup!=null) {
						if(leftTempTup.getPgName()!=tempTup.getPgName()) {
							Page left=null;
							
							left=Page.deserializePage(pageName);
							if(left.getPageTuples().size()<DBApp.max) { 
								Hashtable<String,Object> h=t.getHTBL();
								Vector<Hashtable<String,Object>> temp=left.getPageTuples();
								temp.add(h);
								left.setPageTuples(temp);
								t.setPgName(left.getPageName());
								added=true;
								sortTuples();
							}
						}
					}
					flag=true;
			}
		}
			
			if(x instanceof Integer) {
				if((Integer)x<(Integer)y) { 
					if(leftTempTup!=null) {
						if(!leftTempTup.getPgName().equalsIgnoreCase(tempTup.getPgName())) {
							Page left=null;
							left=Page.deserializePage(pageName);
							if(left.getPageTuples().size()<DBApp.max) {
								Hashtable<String,Object> h=t.getHTBL();
								Vector<Hashtable<String,Object>> temp=left.getPageTuples();
								temp.add(h);
								left.setPageTuples(temp);
								t.setPgName(left.getPageName());
								added=true;
								sortTuples();
								}
							}
						
					}
					
					flag=true;
				}
			
		}
			if (x instanceof Double) {
				if((Double)x<(Double)y) {
					
					if(leftTempTup!=null) {
						if(leftTempTup.getPgName()!=tempTup.getPgName()) {
							Page left=null;
							
							left=Page.deserializePage(pageName);
							if(left.getPageTuples().size()<DBApp.max) {
								Hashtable<String,Object> h=t.getHTBL();
								Vector<Hashtable<String,Object>> temp=left.getPageTuples();
								temp.add(h);
								left.setPageTuples(temp);
								t.setPgName(left.getPageName());
								added=true;
								sortTuples();
								left.serializePage(left);
							}
						}
					
				}
					flag=true;
			}
		}
			if(flag==false && added==true) {
				splitPageHelper(tempTup,t);
				break; 
			
		}
			else if (flag==true){
				Tuple m=tupleVector.firstElement();
				Page p =Page.deserializePage(m.getPgName());
				
				if(p.getPageTuples().size()<DBApp.max){
					Hashtable<String,Object> h=t.getHTBL();
					Vector<Hashtable<String,Object>> temp=p.getPageTuples();
					temp.add(h);
					tupleVector.add(t);
					t.setPgName(p.getPageName());
					p.setPageTuples(temp);
					sortTuples();
					p.serializePage(p);
					break;
				}
				
				else {
					splitPageHelper(m,t); 
					break; 
				}
			}
		}
	}
		else {
			Hashtable<String, Object> H=t.getHTBL();
			Object key=H.get(clusteringKeyString);
			
			if(key instanceof String) {
				String x=(String)key;
    			Vector<Tuple> tempV=null;
    			if(searchTree.search(x)!=null) {
    				tempV=(Vector<Tuple>) searchTree.search(x);
    				tempV.add((Tuple)t);
    				searchTree.delete((String)key);
    				searchTree.insert((String)key, (Vector<Tuple>)tempV); 
    				}
    			
    			else {
    				Vector<Tuple> insertVector=new Vector<Tuple>();
        			insertVector.add(t);
    				searchTree.insert((String)key, insertVector);
    			}
				BTreeLeafNode n=searchTree.LeafNodeFinder((String)key);
				BTreeNode right= n.getRightSibling();
				BTreeNode left=n.getLeftSibling();
				
				Object keySearch= right.getKey(0);
				Vector<Tuple> valueVec=(Vector<Tuple>) searchTree.search((String)keySearch);
				Tuple value=valueVec.get(0);
				String pageName=value.getPgName();
				Page p=null;
				
				
				p=Page.deserializePage(pageName); 
				
				Page pLeft=null;
				if(left!=null) {
				Object keySearchLeft=left.getKey(left.getKeyCount()-1);
				Vector<Tuple> valueVec1=(Vector<Tuple>) searchTree.search((String)keySearchLeft);
				Tuple Leftvalue=valueVec1.get(0);
				
				
				String pageNameLeft=Leftvalue.getPgName();
				
				if(p.getPageName()!=Leftvalue.getPgName()) {
				
					pLeft=Page.deserializePage(pageNameLeft);
					
			}
		}  
				boolean added=false;
				if (p!=null && pLeft!=null) {
					if(pLeft.getPageTuples().size()<DBApp.max) {
						Hashtable<String,Object> h=t.getHTBL();
						Vector<Hashtable<String,Object>> temp=pLeft.getPageTuples();
						temp.add(h);
						pLeft.setPageTuples(temp);
						t.setPgName(pLeft.getPageName());
						added=true;
						p.serializePage(p);
						pLeft.serializePage(pLeft);
						sortTuples();
					}
					
				}
				
				else{
					
					if (added==false && p!=null) {
						splitPageHelper(value, t);
						
				}
					else if (pLeft==null) {
						BTreeLeafNode m=searchTree.getSmallest();
						String kv= (String) m.getKey(0);
						 Vector <Tuple>v=(Vector<Tuple>)searchTree.search(kv);
						 Tuple tv=v.get(0);
						 Page p1 =Page.deserializePage(tv.getPgName());
						
						 if(p1.getPageTuples().size()<DBApp.max){
							Hashtable<String,Object> h=t.getHTBL();
							
							Vector<Hashtable<String,Object>> temp=p1.getPageTuples();
							
							Hashtable hasht=t.getHTBL();
							String Keyhash=(String)hasht.get(clusteringKeyString);
							temp.add(h);
							v.add(t);
							
							p1.setPageTuples(temp);
							t.setPgName(p1.getPageName());
							p1.serializePage(p1);
							
							searchTree.insert(Keyhash,v);
							sortTuples();
							
						}
						else {
							splitPageHelper(tv,t); 
							
						}
						
					}
					
			}

	} 

			else {

				if(key instanceof Double) {
					
					
						double x=(double)key;
		    			Vector<Tuple> tempV=null;
		    			if(searchTree.search(x)!=null) {
		    				tempV=(Vector<Tuple>) searchTree.search(x);
		    				tempV.add((Tuple)t);
		    				searchTree.delete((double)key);
		    				searchTree.insert((double)key, (Vector<Tuple>)tempV); 
		    				}
		    			
		    			else {
		    				Vector<Tuple> insertVector=new Vector<Tuple>();
		        			insertVector.add(t);
		    				searchTree.insert((double)key, insertVector);
		    			}
					BTreeLeafNode n=searchTree.LeafNodeFinder((double)key);
					BTreeNode right= n.getRightSibling();
					BTreeNode left=n.getLeftSibling();
					
					Object keySearch= right.getKey(0);
					Vector<Tuple> valueVec=(Vector<Tuple>) searchTree.search((double)keySearch);
					Tuple value=valueVec.get(0);
					String pageName=value.getPgName();
					Page p=null;
					
					p=Page.deserializePage(pageName);

					
					Page pLeft=null;
					if(left!=null) {
					Object keySearchLeft=left.getKey(left.getKeyCount()-1);
					Vector<Tuple> valueVec1=(Vector<Tuple>) searchTree.search((double)keySearchLeft);
					Tuple Leftvalue=valueVec1.get(0);
					
					
					String pageNameLeft=Leftvalue.getPgName();
					
					if(p.getPageName()!=Leftvalue.getPgName()) {
					
						pLeft=Page.deserializePage(pageNameLeft);
						
				}
			} 
					boolean added=false;
					if (p!=null && pLeft!=null) {
						if(pLeft.getPageTuples().size()<DBApp.max) {
							Hashtable<String,Object> h=t.getHTBL();
							Vector<Hashtable<String,Object>> temp=pLeft.getPageTuples();
							temp.add(h);
							pLeft.setPageTuples(temp);
							t.setPgName(pLeft.getPageName());
							added=true;
							p.serializePage(p);
							pLeft.serializePage(pLeft);
							sortTuples();
						}
						
					}
					
					else{
						
						if (added==false && p!=null) {
							splitPageHelper(value, t);
							
					}
						else if (pLeft==null) {
							BTreeLeafNode m=searchTree.getSmallest();
							double kv= (double) m.getKey(0);
							 Vector <Tuple>v=(Vector<Tuple>)searchTree.search(kv);
							 Tuple tv=v.get(0);
							 Page p1 =Page.deserializePage(tv.getPgName());
							if(p1.getPageTuples().size()<DBApp.max){
								Hashtable<String,Object> h=t.getHTBL();
								Vector<Hashtable<String,Object>> temp=p1.getPageTuples();
								Hashtable hasht=t.getHTBL();
								double Keyhash=(double)hasht.get(clusteringKeyString);
								temp.add(h);
								v.add(t);
								
								p1.setPageTuples(temp);
								t.setPgName(p1.getPageName());
								p1.serializePage(p1);
								
								searchTree.insert(Keyhash,v);
								sortTuples();
								
							}
							else {
								splitPageHelper(tv,t); 
								
							}
						}
					} 
				}
				
				
			else {
				if(key instanceof Integer) {
					
						int x=(int)key;
		    			Vector<Tuple> tempV=null;
		    			if(searchTree.search(x)!=null) {
		    				tempV=(Vector<Tuple>) searchTree.search(x);
		    				tempV.add((Tuple)t);
		    				searchTree.delete((int)key);
		    				searchTree.insert((int)key, (Vector<Tuple>)tempV); 
		    				}
		    			
		    			else {
		    				Vector<Tuple> insertVector=new Vector<Tuple>();
		        			insertVector.add(t);
		    				searchTree.insert((int)key, insertVector);
		    			}
					BTreeLeafNode n=searchTree.LeafNodeFinder((int)key);
					BTreeNode right= n.getRightSibling();
					BTreeNode left=n.getLeftSibling();
					
					Object keySearch= right.getKey(0);
					Vector<Tuple> valueVec=(Vector<Tuple>) searchTree.search((int)keySearch);
					Tuple value=valueVec.get(0);
					String pageName=value.getPgName();
					Page p=null;
					
					p=Page.deserializePage(pageName);
					
					Page pLeft=null;
					if(left!=null) {
					Object keySearchLeft=left.getKey(left.getKeyCount()-1);
					Vector<Tuple> valueVec1=(Vector<Tuple>) searchTree.search((int)keySearchLeft);
					Tuple Leftvalue=valueVec1.get(0);
					
					String pageNameLeft=Leftvalue.getPgName();
					
					if(p.getPageName()!=Leftvalue.getPgName()) {
					
						pLeft=Page.deserializePage(pageNameLeft);
						
				}
			}  
					boolean added=false;
					if (p!=null && pLeft!=null) {
						if(pLeft.getPageTuples().size()<DBApp.max) {
							Hashtable<String,Object> h=t.getHTBL();
							Vector<Hashtable<String,Object>> temp=pLeft.getPageTuples();
							temp.add(h);
							pLeft.setPageTuples(temp);
							t.setPgName(pLeft.getPageName());
							added=true;
							p.serializePage(p);
							pLeft.serializePage(pLeft);
							sortTuples();
						}
						
					}
					
					else{
						
						if (added==false && p!=null) {
							splitPageHelper(value, t);
							
					}
						else if (pLeft==null) {
							BTreeLeafNode m=searchTree.getSmallest();
							int kv= (int) m.getKey(0);
							 Vector <Tuple>v=(Vector<Tuple>)searchTree.search(kv);
							 Tuple tv=v.get(0);
							 Page p1 =Page.deserializePage(tv.getPgName());
							if(p1.getPageTuples().size()<DBApp.max){
								Hashtable<String,Object> h=t.getHTBL();
								Vector<Hashtable<String,Object>> temp=p1.getPageTuples();
								Hashtable hasht=t.getHTBL();
								int Keyhash=(int)hasht.get(clusteringKeyString);
								temp.add(h);
								v.add(t);
								
								p1.setPageTuples(temp);
								t.setPgName(p1.getPageName());
								p1.serializePage(p1);
								
								searchTree.insert(Keyhash,v);
								sortTuples();
								
							}
							
							else {
								splitPageHelper(tv,t); 
								
							}
						}
					}
				}
			}
		}
	} 
}
	

			
	public void splitPageHelper(Tuple tempTup, Tuple t) throws DBAppException, IOException {
		Hashtable<String, Object> H=t.getHTBL();
		String s1=tempTup.getPgName();
		System.out.println(s1);
		Page p=new Page(s1+ " +");
		
		
		Page og = null;
		Vector <Hashtable<String,Object>> newPageTuple=new Vector<Hashtable<String,Object>>();
		Vector <Hashtable<String,Object>> OldpageTuples=new Vector<Hashtable<String,Object>>();
		
		newPageTuple.add(H);
		System.out.println(p.getPageName());
		t.setPgName(s1+" +");
		tempTup.setPgName(s1+ " +");

		og=Page.deserializePage(s1);		
		OldpageTuples=og.getPageTuples();
		
		
		for (int j=0; j<OldpageTuples.size();j++) {
			boolean f=false;
			if (tempTup.getHTBL().equals(OldpageTuples.get(j))) {
				f=true;
			}
			
			
			if(f==true) {
				newPageTuple.add(OldpageTuples.get(j));
				tempTup.setPgName(p.getPageName());
				OldpageTuples.remove(OldpageTuples.get(j));
			}
	}

		
		og.setPageTuples(OldpageTuples);
		p.setPageTuples(newPageTuple);
		t.setPgName(p.getPageName());
		og.serializePage(og);
		p.serializePage(p);
		tupleVector.add(t);
		sortTuples();
		
	}


	public String ClusteringKeyRdr(String strTableName) throws DBAppException, IOException {
	BufferedReader rdr = new BufferedReader(new FileReader("metadata.csv"));
    String line;
    StringBuilder meta = new StringBuilder();
    String clustering=null;
    	while ((line = rdr.readLine()) != null) {
    		if(line.length()!=0) {
        	String[] parts = line.split(",");
            if(parts[0].equals(strTableName) && parts[3].equalsIgnoreCase("true")) {
  
            	clustering=parts[1]; 
            }
 
            }
    	}
            	return clustering;
    } 
            	
  
	public void deleteHelper(Object[][] Deletes, Hashtable<String,Object> HT) throws DBAppException, FileNotFoundException, IOException {
		Hashtable<String, BTree> trees=this.getTree();
		Hashtable<String,String> indices=this.getIndices();
		Vector<Tuple> tempVector= null;
		Tuple tempVT=null;
		Hashtable tempHTV=null;
		boolean f=true;
		
		for(int i=0;i<Deletes.length;i++) {
			
			BTree tempTree=trees.get(Deletes[i][0]);
			BTree OldTree=trees.get(Deletes[i][0]);
			String indexName=indices.get(Deletes[i][0]);
			if(tempTree!=null) {
			if(Deletes[i][1] instanceof Double) {
				tempVector=(Vector<Tuple>) tempTree.search((Double)Deletes[i][1]);}
			
			else if(Deletes[i][1] instanceof Integer) {
				tempVector=(Vector<Tuple>) tempTree.search((int)Deletes[i][1]);}
			
			else if(Deletes[i][1] instanceof String) {
				tempVector=(Vector<Tuple>) tempTree.search((String)Deletes[i][1]);
				}
			else {
				throw new DBAppException("type not supported");}
			
			Hashtable<String, BTree> oldHTB=new Hashtable<String,BTree>();
			oldHTB.put(indexName, OldTree);
			Hashtable<String, BTree> newHTB=new Hashtable<String,BTree>();
			
			if (tempVector !=null) {
			for(int j=0;j<tempVector.size();j++) {
				for(int k=0;k<Deletes.length;k++) {
					tempVT=tempVector.get(k);
					tempHTV=tempVT.getHTBL();
					if (tempHTV.get(Deletes[k][0])!=Deletes[k][1]){
						f=false;
						break;
					}
				}
				if (f==true) {
					if(Deletes[i][1] instanceof Double) {
						tempVector.remove(tempVT);
						tempTree.delete((double)Deletes[i][1]);
						if(tempVector.size()>0) {
							tempTree.insert((double)Deletes[i][1], tempVector); 
							
						}						
					}
					
					else if(Deletes[i][1] instanceof Integer) {
						tempVector.remove(tempVT);
						tempTree.delete((int)Deletes[i][1]);
						if(tempVector.size()>0) {
							tempTree.insert((int)Deletes[i][1], tempVector);
						}}
					
					else if(Deletes[i][1] instanceof String) {
						tempVector.remove(tempVT);
						tempTree.delete((String)Deletes[i][1]);
						if(tempVector.size()>0) {
							tempTree.insert((String)Deletes[i][1], tempVector);
						}}
					else {
						throw new DBAppException("type not supported");}
					
					
					newHTB.put(indexName, tempTree);
					DBApp.trees.remove(oldHTB);
					DBApp.trees.add(newHTB);
				} 
			
					if(tupleVector.contains(tempVT)==true) {
					tupleVector.remove(tempVT);
					
					String pgName=tempVT.getPgName();
					Page p=Page.deserializePage(pgName);
					Vector<Hashtable<String, Object>> tempHTB= p.getPageTuples();
					tempHTB.remove(tempHTV);
					p.setPageTuples(tempHTB);
					if (p.getPageTuples().size()<=0) { 
						DBApp.pageVector.remove(p);
					}
					else {
						p.serializePage(p);
					}
				}
			}
		}}
					
					
					else {
						String sort = ClusteringKeyRdr(this.name);
						if(HT.containsKey(sort)) {
							int number=DBApp.binarySearchIterator(tupleVector, HT.get(sort), sort);
							if(number!=-1) {
							tempVT=tupleVector.get(number);
							for(int k=0;k<Deletes.length;k++) {
								tempHTV=tempVT.getHTBL();
								if (!tempHTV.get(Deletes[k][0]).equals(Deletes[k][1])){
									f=false;
									break;
								}
								else {
									f=true;
								}
							}
						}
					}
						
					
						else {
						for(int l=0;l<tupleVector.size();l++) {
							tempVT=tupleVector.get(l);
							Hashtable H=tempVT.getHTBL();
							for(int k=0;k<Deletes.length;k++) {
								tempHTV=tempVT.getHTBL();
								if (!tempHTV.get(Deletes[k][0]).equals(Deletes[k][1])){
									f=false;
									break;
						}
								else {
									f=true;
								}
							}
						}
					}
						if (f!=false) {
							if(tupleVector.contains(tempVT)==true) {
							tupleVector.remove(tempVT);
							
							String pgName=tempVT.getPgName(); 
							Page p=Page.deserializePage(pgName);
							Vector<Hashtable<String, Object>> tempHTB= p.getPageTuples();
							tempHTB.remove(tempHTV);
							p.setPageTuples(tempHTB);
							if (p.getPageTuples().size()<=0) { 
								DBApp.pageVector.remove(p);
							}
							else {
								p.serializePage(p);
							}
							}
						}
						
					}
					
					
			
				}
			}
		
			
	
	
	
	public Hashtable<String,BTree> getTree() throws FileNotFoundException, IOException{
			Hashtable <String,BTree> result=new Hashtable<String,BTree>();
			Hashtable<String,String> index=this.getIndices();
			Enumeration<String> indexEnum=index.keys();
			while(indexEnum.hasMoreElements()) {
				String columnName=indexEnum.nextElement();
		    	String indexName=index.get(columnName); 

						BTree tree=BTree.deserializeTree(indexName);
						result.put(columnName, tree);
						tree.serializeTree(tree);
							}
						
					
			return result;
	}} 
				
			    	
	


