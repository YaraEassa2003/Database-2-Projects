package DB.DBproject;
import java.util.Enumeration;
import java.util.Hashtable;

//Class that should be used when inserting new tuple

public class Tuple extends Page{
	private int counter=0;
	private String tupName;
	String strTableName;
	Hashtable<String,Object>  htblColNameValue;
	String pageName;
	
	public Tuple(String strTableName, 
			Hashtable<String,Object>  htblColNameValue) {
		//this.page--;
		super(0);
		counter++;
		tupName="Tuple "+counter;
		this.strTableName=strTableName;
		this.htblColNameValue=htblColNameValue;
		this.pageName=null;
	}
	
	public String toString() {
		//override toString
		String s="";		
		Enumeration<String> keys = htblColNameValue.keys();
			while(keys.hasMoreElements()) {
			    	String name=keys.nextElement();
			    	Object value=htblColNameValue.get(name);
			s=s+name+","+value+",";   
			}
			return s;	
	}
	
	public Hashtable<String,Object> getHTBL() {
		return this.htblColNameValue;
		
	}
	
	public void setHTBL(Hashtable<String,Object> htblColNameValue) {
		 this.htblColNameValue=htblColNameValue;
	}
	
	public void setPgName(String pageName) {
		this.pageName=pageName;
	}
	
	public String getPgName() {
		return this.pageName;
	}
	
	public String getTableName() {
		return this.strTableName;
	}
	

}
